import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-collapse',
  templateUrl: './text-collapse.component.html',
  styleUrls: ['./text-collapse.component.css']
})
export class TextCollapseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}